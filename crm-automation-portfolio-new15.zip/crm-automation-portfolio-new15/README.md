# CRM & Workflow Automation Portfolio

This is a freelancer portfolio website for Ana Lingatong, showcasing **CRM and workflow automation services** for small businesses.

## Features
- CRM Automation services
- Workflow Automation services
- Contact form for inquiries
- Portfolio and service details

## Tech Stack
- HTML5
- CSS3
- JavaScript

## Usage
1. Clone the repository:
